"""Approvals, simulated work orders and the HTTP API, driven the way the dashboard drives them."""
import time

import pytest
from fastapi.testclient import TestClient

from acumain import schema
from acumain.api import create_app
from acumain.config import ARTIFACTS
from acumain.services import SAMPLE_ID, RequestError


@pytest.fixture
def client(svc):
    return TestClient(create_app(svc))


def wait_for(client, run_id, seconds=20):
    deadline = time.time() + seconds
    while time.time() < deadline:
        run = client.get(f"/api/agent/runs/{run_id}").json()
        if run["status"] != "running":
            return run
        time.sleep(0.05)
    raise AssertionError("the run did not finish in time")


def review(client, **body):
    started = client.post("/api/agent/runs", json={"batch_id": SAMPLE_ID, "kind": "review", **body})
    assert started.status_code == 202
    return wait_for(client, started.json()["run_id"])


# ---------------------------------------------------------------------------- approvals
def test_nothing_is_executed_until_a_person_approves(svc):
    svc.start_run(SAMPLE_ID, "review", list_size=6, wait=True)
    pending = svc.store.list_proposals(batch_id=SAMPLE_ID, status="pending")
    assert len(pending) == 6 and svc.store.list_work_orders() == []
    approved = svc.decide(pending[0]["id"], "approved")
    rejected = svc.decide(pending[1]["id"], "rejected", note="Aircraft is leaving the fleet.")
    assert approved["status"] == "approved" and approved["work_order_id"] == "WO-SIM-0001" and approved["decided_by"] == "planner"
    assert rejected["status"] == "rejected" and rejected["work_order_id"] is None and rejected["decision_note"] == "Aircraft is leaving the fleet."
    orders = svc.store.list_work_orders()
    assert len(orders) == 1 and orders[0]["status"] == "Created (simulated)" and orders[0]["record_id"] == pending[0]["record_id"]
    with pytest.raises(RequestError) as err:                                         # a decision is final
        svc.decide(pending[0]["id"], "rejected")
    assert err.value.status == 409 and "already approved" in str(err.value)
    assert svc.decide(pending[0]["id"], "approved")["work_order_id"] == "WO-SIM-0001"   # saying it twice changes nothing
    assert len(svc.store.list_work_orders()) == 1


def test_a_new_review_replaces_pending_proposals_but_never_a_decision(svc):
    svc.start_run(SAMPLE_ID, "review", list_size=4, wait=True)
    first = svc.store.list_proposals(batch_id=SAMPLE_ID)
    svc.decide(first[0]["id"], "approved")
    run = svc.store.get_run(svc.start_run(SAMPLE_ID, "review", list_size=4, wait=True))
    filed = [s for s in run["steps"] if s["name"] == "propose_actions"][0]["output"]
    assert filed["filed_for_review"] == 4 and filed["replaced_earlier_pending_proposals"] == 3 and filed["not_filed"] == []
    now = svc.store.list_proposals(batch_id=SAMPLE_ID)
    assert len(now) == 5 and sum(p["status"] == "approved" for p in now) == 1 and sum(p["status"] == "pending" for p in now) == 4
    assert first[0]["record_id"] not in {p["record_id"] for p in now if p["status"] == "pending"}    # the approved one was left alone


def test_bulk_decisions_can_target_one_kind_of_action(svc):
    svc.start_run(SAMPLE_ID, "review", list_size=25, wait=True)
    done = svc.decide_many(SAMPLE_ID, "approved", action="repair")
    assert len(done) == 22 and len(svc.store.list_work_orders(SAMPLE_ID)) == 22
    assert [p["action"] for p in svc.store.list_proposals(batch_id=SAMPLE_ID, status="pending")] == ["retest"] * 3


# ---------------------------------------------------------------------------- HTTP API
def test_health_meta_and_static_page(client):
    health = client.get("/api/health").json()
    assert health["status"] == "ok" and health["model"]["available"] and health["agent"]["mode"] == "offline"
    meta = client.get("/api/meta").json()
    assert meta["thresholds"] == {"medium": 10.0, "high": 32.0} and len(meta["fields"]) == 14 and meta["validation"]["caught"] == 185
    assert client.get("/api/history").json()["model"]["failures"] == 187
    assert client.get("/api/files/template.csv").text.startswith("Case_ID,Aircraft_ID")
    assert "<title>" in client.get("/").text


def test_a_review_through_the_api_then_browse_and_decide(client):
    before = client.get(f"/api/batches/{SAMPLE_ID}").json()
    assert before["records"] == 2000 and not before["scored"]
    unscored_page = client.get(f"/api/batches/{SAMPLE_ID}/records", params={"limit": 3}).json()
    assert unscored_page["total"] == 2000 and unscored_page["rows"][0]["level"] in ("Awaiting model", "Not scored")

    run = review(client, list_size=10, screen={"page": "Review queue", "filter": "Any", "secret": "dropped"})
    assert run["status"] == "completed" and run["context"]["screen"] == {"page": "Review queue", "filter": "Any"}
    after = client.get(f"/api/batches/{SAMPLE_ID}").json()
    assert after["scored"] and after["levels"]["High"] == 203 and after["proposals"]["pending"] == 10 and after["active_run"] is None

    high = client.get(f"/api/batches/{SAMPLE_ID}/records", params={"level": "High", "limit": 5}).json()
    assert high["total"] == 203 and high["rows"][0]["proposal"]["status"] == "pending" and high["rows"][0]["risk"] > 90
    found = client.get(f"/api/batches/{SAMPLE_ID}/records", params={"q": high["rows"][0]["aircraft_id"].lower()}).json()
    assert found["total"] == 1
    assert client.get(f"/api/batches/{SAMPLE_ID}/records", params={"issues": True}).json()["total"] == 448

    detail = client.get(f"/api/batches/{SAMPLE_ID}/records/{high['rows'][0]['record_id']}").json()
    assert detail["level"] == "High" and detail["factors"] and detail["band"]["in_30_days"] > 50 and detail["proposal"]["action"] == "repair"
    assert client.get(f"/api/batches/{SAMPLE_ID}/records/NOPE").status_code == 404

    proposals = client.get(f"/api/batches/{SAMPLE_ID}/proposals").json()
    one = client.post(f"/api/proposals/{proposals[0]['id']}/decision", json={"decision": "approved"}).json()
    assert one["work_order_id"].startswith("WO-SIM-")
    assert client.post(f"/api/proposals/{proposals[1]['id']}/decision", json={"decision": "maybe"}).status_code == 400
    rest = client.post(f"/api/batches/{SAMPLE_ID}/proposals/decision", json={"decision": "rejected"}).json()
    assert len(rest) == 9 and len(client.get("/api/work-orders").json()) == 1
    assert len(client.get("/api/agent/runs").json()) == 1

    reset = client.post(f"/api/batches/{SAMPLE_ID}/reset").json()
    assert not reset["scored"] and reset["proposals"] == {"pending": 0, "approved": 0, "rejected": 0} and client.get("/api/work-orders").json() == []


def test_upload_a_file_and_review_it(client):
    content = (ARTIFACTS / "sample_upload.csv").read_bytes()
    made = client.post("/api/batches", files={"file": ("this_week.csv", content, "text/csv")}, data={"name": "This week"})
    assert made.status_code == 201
    batch = made.json()
    assert batch["name"] == "This week" and batch["records"] == 30 and batch["source"] == "upload" and batch["with_issues"] >= 8
    started = client.post("/api/agent/runs", json={"batch_id": batch["id"], "kind": "review", "list_size": 5})
    run = wait_for(client, started.json()["run_id"])
    assert run["status"] == "completed" and client.get(f"/api/batches/{batch['id']}").json()["scored"]
    assert len(client.get("/api/batches").json()) == 2
    assert client.delete(f"/api/batches/{batch['id']}").json() == {"removed": batch["id"]}
    assert client.delete(f"/api/batches/{SAMPLE_ID}").status_code == 400          # the built-in sample stays


def test_a_file_with_answers_is_scored_honestly(client, sample_frame):
    frame = sample_frame.head(40).copy()
    frame[schema.ANSWER_COLUMN] = ["Yes" if i % 9 == 0 else "No" for i in range(len(frame))]
    made = client.post("/api/batches", files={"file": ("labelled.csv", frame.to_csv(index=False).encode(), "text/csv")}).json()
    wait_for(client, client.post("/api/agent/runs", json={"batch_id": made["id"], "kind": "review"}).json()["run_id"])
    check = client.get(f"/api/batches/{made['id']}").json()["answer_check"]
    assert check["records"] == check["caught"] + check["missed"] + check["false_alarms"] + check["correct_no"] and 0 <= check["f1"] <= 100


@pytest.mark.parametrize("name, content, expect", [
    ("bad.csv", b"a,b\n1,2\n", "14 required column(s)"), ("empty.csv", b"", "empty"), ("sheet.xlsx", b"PK\x03\x04", "CSV")])
def test_unusable_uploads_are_refused_with_a_reason(client, name, content, expect):
    answer = client.post("/api/batches", files={"file": (name, content, "text/csv")})
    assert answer.status_code == 422 and expect in answer.json()["detail"]


def test_single_record_check(client):
    values = {"Hydraulic_Fluid_Grade": "FG-A", "Flight_Hours_Last_7_Days": 80, "Flight_Cycles_Last_7_Days": 12, "Actuator_Age_Hours": 2500,
              "Days_Since_Last_Service": 90, "Ambient_Temperature_C": 25, "Hydraulic_Pressure_PSI": 5000, "Pressure_Variation_PSI": 80,
              "Hydraulic_Fluid_Temperature_C": 55, "Internal_Leakage_Rate_mL_Min": 26, "Actuation_Time_Seconds": 5.5,
              "Reference_Leakage_Flow_mL_Min": 50, "Reference_Actuation_Time_Seconds": 6, "Diagnostic_Load_Ratio": 1.0}
    worn = client.post("/api/predict", json={"values": values}).json()
    assert worn["level"] == "High" and worn["prediction"] == "Yes" and worn["confidence"].startswith("Normal")
    partial = client.post("/api/predict", json={"values": {**values, "Internal_Leakage_Rate_mL_Min": None}}).json()
    assert partial["level"] in ("High", "Medium", "Low") and partial["confidence"].startswith("Reduced") and "Internal leakage rate is missing." in partial["issues"]
    nothing = client.post("/api/predict", json={"values": {**values, "Internal_Leakage_Rate_mL_Min": "", "Actuation_Time_Seconds": "abc"}}).json()
    assert nothing["level"] == "Not scored" and nothing["risk"] is None and nothing["prediction"] is None


WORN = {"Aircraft_ID": "B787-102", "Hydraulic_Fluid_Grade": "FG-A", "Flight_Hours_Last_7_Days": 95, "Flight_Cycles_Last_7_Days": 16,
        "Actuator_Age_Hours": 3400, "Days_Since_Last_Service": 180, "Ambient_Temperature_C": 31, "Hydraulic_Pressure_PSI": 4950,
        "Pressure_Variation_PSI": 78, "Hydraulic_Fluid_Temperature_C": 62, "Internal_Leakage_Rate_mL_Min": 24, "Actuation_Time_Seconds": 5.4,
        "Reference_Leakage_Flow_mL_Min": 50, "Reference_Actuation_Time_Seconds": 6, "Diagnostic_Load_Ratio": 1}


def review_one(client, values):
    """Type one record in, let the team review it, and return the file, the run and what was proposed."""
    made = client.post("/api/batches/record", json={"values": values})
    assert made.status_code == 201
    batch = made.json()
    assert batch["records"] == 1 and batch["source"] == "manual"
    run = wait_for(client, client.post("/api/agent/runs", json={"batch_id": batch["id"], "kind": "review"}).json()["run_id"])
    assert run["status"] == "completed" and run["context"]["team"] is True
    return batch, run, client.get(f"/api/batches/{batch['id']}/proposals").json()


def test_one_typed_record_is_reviewed_by_the_same_team(client, svc):
    batch, run, proposals = review_one(client, WORN)
    assert batch["name"] == "Single record · B787-102"
    called = [s["name"] for s in run["steps"] if s["type"] == "tool"]
    assert called[:3] == ["assign_risk_agent", "check_records", "run_failure_model"] and "assign_stock_agent" in called and "reserve_parts" in called
    assert [(p["aircraft_id"], p["action"], p["level"], p["part"]["status"]) for p in proposals] == [("B787-102", "repair", "High", "in_store")]
    assert "This aircraft is predicted to fail within 30 days" in run["final_text"] and "1 of the 1" not in run["final_text"]
    # the planner decides with one click each way; nothing is asked of them
    assert client.post(f"/api/proposals/{proposals[0]['id']}/decision", json={"decision": "approved"}).json()["work_order_id"].startswith("WO-SIM-")
    assert client.delete(f"/api/batches/{batch['id']}").status_code == 200           # a typed record can be removed like an upload


def test_a_healthy_record_gets_no_action_and_a_blank_one_a_repeat_test(client):
    healthy = {**WORN, "Aircraft_ID": "B787-101", "Actuator_Age_Hours": 1500, "Pressure_Variation_PSI": 55, "Internal_Leakage_Rate_mL_Min": 4, "Actuation_Time_Seconds": 3.9}
    _batch, run, proposals = review_one(client, healthy)
    assert proposals == [] and "needs no action now" in run["final_text"]
    assert "assign_stock_agent" not in [s["name"] for s in run["steps"] if s["type"] == "tool"]      # no repair, so no parts are looked for

    blank = {**WORN, "Aircraft_ID": "  ", "Internal_Leakage_Rate_mL_Min": "", "Actuation_Time_Seconds": None}
    batch, run, proposals = review_one(client, blank)
    assert batch["name"] == "Single record" and batch["not_scorable"] == 1
    assert [(p["aircraft_id"], p["action"], p["risk"]) for p in proposals] == [("Unnamed aircraft", "retest", None)]
    assert "No prediction could be made" in run["final_text"] and "0 of the 0" not in run["final_text"]
    rejected = client.post(f"/api/proposals/{proposals[0]['id']}/decision", json={"decision": "rejected"}).json()
    assert rejected["status"] == "rejected" and rejected["decision_note"] is None and rejected["work_order_id"] is None


def test_a_typed_record_with_odd_values_is_cleaned_not_refused(client):
    odd = {**WORN, "Aircraft_ID": "<b>X</b>" + "9" * 90, "Hydraulic_Fluid_Grade": "XX", "Pressure_Variation_PSI": "abc", "Ambient_Temperature_C": 9999, "Unknown_Column": 1}
    made = client.post("/api/batches/record", json={"values": odd}).json()
    record = client.get(f"/api/batches/{made['id']}/records").json()["rows"][0]
    assert len(record["aircraft_id"]) <= schema.MAX_ID_LENGTH and record["issues"] == 3 and record["scorable"]
    assert client.post("/api/batches/record", json={"values": "not an object"}).status_code == 422
    empty = client.post("/api/batches/record", json={"values": {}}).json()               # nothing typed at all: stored, and reported as unusable
    assert empty["records"] == 1 and empty["not_scorable"] == 1


def test_model_outage_is_visible_everywhere_and_recoverable(client):
    assert client.post("/api/demo/outage", json={"enabled": True}).json()["available"] is False
    assert client.get("/api/health").json()["model"]["simulated_outage"] is True
    failed = client.post("/api/predict", json={"values": {}})
    assert failed.status_code == 503 and failed.json()["code"] == "MODEL_UNAVAILABLE"
    run = review(client)
    assert run["proposals"] == [] and "no predictions" in run["final_text"] and not client.get(f"/api/batches/{SAMPLE_ID}").json()["scored"]
    client.post("/api/demo/outage", json={"enabled": False})
    assert len(review(client, list_size=5)["proposals"]) == 5                       # the retry works


def test_bad_run_requests_are_refused(client, svc):
    post = lambda **body: client.post("/api/agent/runs", json=body)
    assert post(batch_id="nope", kind="review").status_code == 404
    assert post(batch_id=SAMPLE_ID, kind="delete").status_code == 400
    assert post(batch_id=SAMPLE_ID, kind="question", question=" ").status_code == 400
    assert post(batch_id=SAMPLE_ID, kind="question", question="x" * 601).status_code == 400
    assert post(batch_id=SAMPLE_ID, kind="review", record_ids=["nope"]).status_code == 400
    svc.store.create_run("review", "busy", SAMPLE_ID, "test", "test", {})
    assert post(batch_id=SAMPLE_ID, kind="review").status_code == 409
    assert client.post(f"/api/batches/{SAMPLE_ID}/reset").status_code == 409
    assert client.get("/api/agent/runs/run_nope").status_code == 404


def test_uploaded_batches_and_results_survive_a_restart(svc, settings):
    from acumain.services import Services
    batch = svc.upload((ARTIFACTS / "sample_upload.csv").read_bytes(), "kept.csv", None)
    svc.start_run(batch.id, "review", list_size=3, wait=True)
    svc.start_run(SAMPLE_ID, "review", list_size=3, wait=True)
    again = Services(settings)
    assert again.batch(batch.id).scored and again.batch(SAMPLE_ID).scored and again.batch(batch.id).name == "kept"
    assert len(again.store.list_proposals(batch_id=batch.id)) == 3 and len(again.batches.all()) == 2


def test_only_one_of_many_simultaneous_starts_is_accepted(svc):
    """Found by stress-testing the running app: two reviews could start on one batch at the same instant."""
    import threading
    from acumain.services import RequestError
    outcomes, barrier = [], threading.Barrier(8)

    def start():
        barrier.wait()
        try:
            outcomes.append(svc.start_run(SAMPLE_ID, "review", list_size=5))
        except RequestError as err:
            outcomes.append(err.status)

    threads = [threading.Thread(target=start) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    started = [o for o in outcomes if isinstance(o, str)]
    assert len(started) == 1 and outcomes.count(409) == 7
    svc._threads[started[0]].join(timeout=20)
    assert svc.store.get_run(started[0])["status"] == "completed" and len(svc.store.list_runs()) == 1


def test_racing_decisions_create_exactly_one_work_order(svc):
    import threading
    svc.start_run(SAMPLE_ID, "review", list_size=3, wait=True)
    target = svc.store.list_proposals(batch_id=SAMPLE_ID)[0]["id"]
    barrier = threading.Barrier(10)

    def decide(i):
        barrier.wait()
        try:
            svc.decide(target, "approved" if i % 2 else "rejected")
        except RequestError:        # the losers of the race are told their decision did not apply
            pass

    threads = [threading.Thread(target=decide, args=(i,)) for i in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    final = svc.store.list_proposals(batch_id=SAMPLE_ID)[0]
    orders = [o for o in svc.store.list_work_orders() if o["proposal_id"] == target]
    assert final["status"] in ("approved", "rejected") and len(orders) == (1 if final["status"] == "approved" else 0)


# ---------------------------------------------------------------------------- found by an independent review
def test_odd_values_from_the_browser_cannot_poison_the_log(client, svc):
    import json
    body = b'{"batch_id": "sample", "kind": "review", "list_size": 3, "screen": {"page": NaN, "filter": "High", "search": 123, "junk": "x"}}'
    started = client.post("/api/agent/runs", content=body, headers={"Content-Type": "application/json"})
    assert started.status_code in (202, 422)                 # accepted with the bad values dropped, or refused outright
    if started.status_code == 202:
        assert wait_for(client, started.json()["run_id"])["context"]["screen"] == {"filter": "High"}
    run_id = svc.store.create_run("review", "direct", SAMPLE_ID, "test", "test", {"reading": float("nan"), "limit": float("inf")})
    svc.store.finish_run(run_id, "completed", "done")
    listing = client.get("/api/agent/runs")
    assert listing.status_code == 200 and client.get(f"/api/agent/runs/{run_id}").json()["context"] == {"reading": None, "limit": None}
    json.dumps(svc.store.list_runs(), allow_nan=False)        # strict JSON all the way through


def test_reset_archives_old_runs_so_the_queue_starts_clean(client, svc):
    review(client, list_size=3)
    assert client.post(f"/api/batches/{SAMPLE_ID}/reset").status_code == 200
    review(client, list_size=3)
    runs = client.get("/api/agent/runs").json()
    assert sorted(r["archived"] for r in runs) == [False, True]
    assert next(r for r in runs if r["archived"])["started_at"] <= next(r for r in runs if not r["archived"])["started_at"]


def test_a_decision_that_did_not_apply_is_reported(client, svc):
    review(client, list_size=3)
    first, second = client.get(f"/api/batches/{SAMPLE_ID}/proposals").json()[:2]
    decide = lambda pid, what: client.post(f"/api/proposals/{pid}/decision", json={"decision": what})
    assert decide(first["id"], "rejected").status_code == 200
    late = decide(first["id"], "approved")
    assert late.status_code == 409 and "already rejected" in late.json()["detail"] and client.get("/api/work-orders").json() == []
    assert decide(first["id"], "rejected").json()["status"] == "rejected"          # the same decision again is harmless
    review(client, list_size=3)                                                    # a new review replaces what was still pending
    stale = decide(second["id"], "approved")
    assert stale.status_code == 409 and "replaced by a newer proposal" in stale.json()["detail"]
    assert decide("P-9999", "approved").status_code == 404


# ---------------------------------------------------------------------------- changing a decision that was already taken
def decide_on(client, proposal_id, what, override=False):
    return client.post(f"/api/proposals/{proposal_id}/decision", json={"decision": what, "override": override})


def test_a_decision_can_be_changed_and_the_work_order_follows(client):
    review(client, list_size=3)
    first = client.get(f"/api/batches/{SAMPLE_ID}/proposals").json()[0]
    order = decide_on(client, first["id"], "approved").json()["work_order_id"]
    assert decide_on(client, first["id"], "rejected").status_code == 409             # without an explicit override nothing changes
    assert [o["status"] for o in client.get("/api/work-orders").json()] == ["Created (simulated)"]

    changed = decide_on(client, first["id"], "rejected", override=True)             # approved -> rejected: the order is cancelled, not deleted
    assert changed.status_code == 200 and changed.json()["status"] == "rejected" and changed.json()["work_order_id"] is None
    assert [(o["id"], o["status"], bool(o["cancelled_at"])) for o in client.get("/api/work-orders").json()] == [(order, "Cancelled (simulated)", True)]

    again = decide_on(client, first["id"], "approved", override=True).json()         # rejected -> approved: a new order, the old one stays on record
    assert again["status"] == "approved" and again["work_order_id"] not in (None, order)
    orders = {o["id"]: o for o in client.get("/api/work-orders").json()}
    assert len(orders) == 2 and orders[order]["cancelled_at"] and not orders[again["work_order_id"]]["cancelled_at"]

    same = decide_on(client, first["id"], "approved", override=True).json()          # the same decision again is harmless
    assert same["work_order_id"] == again["work_order_id"] and len(client.get("/api/work-orders").json()) == 2
    assert client.get(f"/api/batches/{SAMPLE_ID}").json()["proposals"] == {"pending": 2, "approved": 1, "rejected": 0}
    assert decide_on(client, "P-9999", "approved", override=True).status_code == 404
    assert decide_on(client, first["id"], "maybe", override=True).status_code == 400


def test_changing_a_decision_gives_back_or_takes_the_spare_part(client):
    review(client, list_size=5)
    free = lambda: client.get("/api/health").json()["stock"]["free"]
    repair = next(p for p in client.get(f"/api/batches/{SAMPLE_ID}/proposals").json() if p["action"] == "repair" and p["part"]["status"] == "in_store")
    before = free()
    decide_on(client, repair["id"], "approved")
    assert free() == before - 1                                                      # an approved repair keeps its unit
    decide_on(client, repair["id"], "rejected", override=True)
    assert free() == before                                                          # rejecting it gives the unit back
    decide_on(client, repair["id"], "approved", override=True)
    assert free() == before - 1


def test_an_override_never_revives_a_replaced_proposal_or_doubles_an_aircraft(client, svc):
    review(client, list_size=3)
    first, second = client.get(f"/api/batches/{SAMPLE_ID}/proposals").json()[:2]
    assert decide_on(client, first["id"], "rejected").status_code == 200
    review(client, list_size=3)                                                      # the pending ones are replaced by a new review
    stale = decide_on(client, second["id"], "approved", override=True)
    assert stale.status_code == 409 and "replaced by a newer proposal" in stale.json()["detail"]
    # The rejected aircraft is proposed again by a later review. Approving the old rejection now would give it two open actions.
    svc.store.add_proposals(first["run_id"], SAMPLE_ID, [{"record_id": first["record_id"], "aircraft_id": first["aircraft_id"], "action": "repair",
                                                          "note": "", "reason": first["reason"], "risk": first["risk"], "level": first["level"], "time_left": None}])
    blocked = decide_on(client, first["id"], "approved", override=True)
    assert blocked.status_code == 409 and "newer proposal that is still open" in blocked.json()["detail"]
    assert client.get("/api/work-orders").json() == []
    assert next(p for p in client.get(f"/api/batches/{SAMPLE_ID}/proposals").json() if p["id"] == first["id"])["status"] == "rejected"


def test_a_parts_request_decision_can_be_changed(client):
    review(client, list_size=25)                                                     # more repairs than the hangar store holds, so a request is drafted
    request = client.get(f"/api/parts-requests?batch_id={SAMPLE_ID}").json()[0]
    decide = lambda what, override=False: client.post(f"/api/parts-requests/{request['id']}/decision", json={"decision": what, "override": override})
    assert request["status"] == "pending" and decide("rejected").json()["status"] == "rejected"
    late = decide("approved")
    assert late.status_code == 409 and "already rejected" in late.json()["detail"]
    assert decide("approved", override=True).json()["status"] == "approved"
    assert decide("rejected", override=True).json()["status"] == "rejected"
    assert decide("rejected", override=True).json()["status"] == "rejected"          # the same decision again is harmless
    assert client.post("/api/parts-requests/PR-SIM-9999/decision", json={"decision": "approved", "override": True}).status_code == 404


# ---------------------------------------------------------------------------- the steps behind a suggested action
def test_a_record_carries_the_steps_for_each_action_that_fits_it(client):
    review(client, list_size=3)
    top = client.get(f"/api/batches/{SAMPLE_ID}/records", params={"limit": 1}).json()["rows"][0]
    detail = client.get(f"/api/batches/{SAMPLE_ID}/records/{top['record_id']}").json()
    assert set(detail["plans"]) == {"repair", "inspect", "retest", "monitor"} and detail["suggested_action"] == "repair"
    repair = detail["plans"]["repair"]
    assert repair["when"] == "This week" and repair["steps"][0]["do"] == "Book a hangar slot this week." and len(repair["steps"]) >= 5
    unscored = client.get(f"/api/batches/{SAMPLE_ID}/records", params={"level": "Not scored", "limit": 1}).json()["rows"][0]
    only = client.get(f"/api/batches/{SAMPLE_ID}/records/{unscored['record_id']}").json()["plans"]
    assert set(only) == {"retest"} and "no prediction was made" in only["retest"]["steps"][0]["why"]      # nothing but a re-test fits
