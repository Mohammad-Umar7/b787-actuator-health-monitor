"""Everything the web layer needs, built once at start-up: the model, the batches, the store and the agent."""
from __future__ import annotations

import threading

import pandas as pd

from . import schema
from .agent import loop, prompts, team, tools
from .agent.llm import ClaudeLLM, OfflinePlanner
from .batches import Batch, BatchStore
from .config import ARTIFACTS, Settings, get_settings
from .model import RiskModel
from .stock import PRESETS, SimulatedStock
from .store import Store, now

SAMPLE_ID = "sample"
SAMPLE_NAME = "Fleet diagnostics, Jan to May 2026 (sample)"
MAX_SELECTED = 100
MAX_LIST_SIZE = 60


class RequestError(ValueError):
    """The request cannot be carried out. `status` is the HTTP status to answer with."""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


class Services:
    def __init__(self, settings: Settings | None = None, claude=None):
        self.settings = settings or get_settings()
        self.model = RiskModel().load()
        self.store = Store(self.settings.data_dir / "acumain.db")
        self.stock = SimulatedStock(self.store)
        self.batches = BatchStore(self.model, self.settings.data_dir)
        self.batches.load_saved()
        if self.batches.get(SAMPLE_ID) is None:
            raw = pd.read_csv(ARTIFACTS / "sample_records.csv", dtype=str, keep_default_na=False)
            self.batches.add(SAMPLE_NAME, "sample", raw, batch_id=SAMPLE_ID)
        # `claude` can be injected by the tests; otherwise it exists only when a key was configured.
        self.claude = claude if claude is not None else (ClaudeLLM(self.settings) if self.settings.claude_enabled else None)
        self._threads: dict[str, threading.Thread] = {}
        # Starting a run, resetting a batch and removing a batch must not interleave: each checks that no run is
        # active and then acts on that, so the check and the act happen under one lock.
        self._gate = threading.RLock()

    # ------------------------------------------------------------------ status
    def agent_status(self) -> dict:
        spent = self.store.spend_today()
        if self.claude is None:
            reason = ("Claude is switched off in the configuration." if self.settings.agent_mode == "offline"
                      else "No API key is configured, so the built-in planner is used. It costs nothing.")
            mode = "offline"
        elif spent >= self.settings.daily_usd_limit:
            mode, reason = "offline", f"Today's Claude spend limit (${self.settings.daily_usd_limit:.2f}) is used up, so the built-in planner is used."
        else:
            mode, reason = "claude", None
        return {"mode": mode, "model": self.settings.model if mode == "claude" else "built-in planner", "reason": reason,
                "spent_today_usd": round(spent, 4), "daily_limit_usd": self.settings.daily_usd_limit,
                "run_limit_usd": self.settings.run_usd_limit, "effort": self.settings.effort}

    # ------------------------------------------------------------------ batches
    def batch(self, batch_id: str) -> Batch:
        batch = self.batches.get(batch_id)
        if batch is None:
            raise RequestError("That batch does not exist.", 404)
        return batch

    def upload(self, content: bytes, filename: str, name: str | None) -> Batch:
        try:
            raw = schema.read_table(content, filename)
            return self.batches.add(name or filename.rsplit(".", 1)[0], "upload", raw)
        except schema.SchemaError as err:
            raise RequestError(str(err), 422) from err

    def preview(self, values: dict) -> dict:
        """Check and score one record typed into the form. Nothing is stored."""
        row = {col: ("" if values.get(col) is None else str(values.get(col))) for col in schema.REQUIRED}
        row["Case_ID"] = "manual-check"
        row["Aircraft_ID"] = str(values.get("Aircraft_ID") or "Manual check")
        try:
            checked = schema.check(pd.DataFrame([row]))
        except schema.SchemaError as err:
            raise RequestError(str(err), 422) from err
        temp = Batch(id="preview", name="Manual check", source="manual", created_at=now(), checked=checked)
        temp.results = self.model.score(temp.frame, temp.checked.scorable)        # raises ModelUnavailable
        return self.batches.detail(temp, "manual-check")

    def add_record(self, values: dict) -> Batch:
        """One record typed into the form becomes a file of its own, so the team reviews it exactly as it reviews a
        fleet file: same checks, same model call, same stock check, same approval."""
        if not isinstance(values, dict):
            raise RequestError("Send the readings as an object of column names and values.", 422)
        row = {col: ("" if values.get(col) is None else str(values.get(col)).strip()) for col in schema.REQUIRED}
        aircraft = " ".join(str(values.get("Aircraft_ID") or "").split())[:schema.MAX_ID_LENGTH]
        row["Aircraft_ID"] = aircraft or "Unnamed aircraft"
        row["Observation_Date"] = now()[:10]
        try:
            return self.batches.add(f"Single record · {aircraft}" if aircraft else "Single record", "manual", pd.DataFrame([row]))
        except schema.SchemaError as err:
            raise RequestError(str(err), 422) from err

    def reset(self, batch_id: str) -> None:
        with self._gate:
            batch = self.batch(batch_id)
            if self.store.active_run(batch_id):
                raise RequestError("The assistant is still working on this batch.", 409)
            self.batches.clear_results(batch)
            self.store.clear_batch(batch_id)

    def remove(self, batch_id: str) -> None:
        with self._gate:
            if self.store.active_run(batch_id):
                raise RequestError("The assistant is still working on this batch.", 409)
            if not self.batches.remove(batch_id):
                raise RequestError("Only uploaded batches can be removed.", 400)
            self.store.clear_batch(batch_id)

    def proposals_by_record(self, batch_id: str) -> dict:
        """The open or decided proposal for each record, newest first."""
        out: dict = {}
        for p in self.store.list_proposals(batch_id=batch_id):
            if p["record_id"] not in out or p["created_at"] > out[p["record_id"]]["created_at"]:
                out[p["record_id"]] = p
        return out

    # ------------------------------------------------------------------ agent runs
    def start_run(self, batch_id: str, kind: str, question: str | None = None, record_ids: list | None = None,
                  list_size: int = 25, selected: str | None = None, screen: dict | None = None, wait: bool = False,
                  as_team: bool = False) -> str:
        """`as_team` runs a review with the orchestrator, the Risk agent, the Stock agent and the Supply agent.
        Without it the Risk agent works alone, which is also how a question is answered."""
        batch = self.batch(batch_id)
        if kind not in ("review", "question"):
            raise RequestError("kind must be 'review' or 'question'.")
        question = (question or "").strip()
        if kind == "question" and not question:
            raise RequestError("Type a question first.")
        if len(question) > 600:
            raise RequestError("The question is too long. Keep it under 600 characters.")
        known = set(batch.frame["Record_ID"])
        scope = [r for r in dict.fromkeys(record_ids or []) if r in known] or None
        if record_ids and not scope:
            raise RequestError("None of the selected records are in this batch.")
        if scope and len(scope) > MAX_SELECTED:
            raise RequestError(f"Select at most {MAX_SELECTED} records, or review the whole batch.")
        list_size = max(1, min(int(list_size or 25), MAX_LIST_SIZE))
        selected = selected if selected in known else None
        screen = {k: str(v)[:80] for k, v in (screen or {}).items() if k in ("page", "filter", "search") and isinstance(v, str) and v.strip()}

        status = self.agent_status()
        primary = self.claude if status["mode"] == "claude" else None
        planner = OfflinePlanner(kind, list_size, selected)
        as_team = bool(as_team) and kind == "review"
        context = {"kind": kind, "question": question or None, "record_ids": scope, "list_size": list_size, "selected": selected, "screen": screen,
                   "team": as_team}
        task = "Prepare the action list" if kind == "review" else question
        with self._gate:
            if self.store.active_run(batch_id):
                raise RequestError("The assistant is already working on this batch. Wait for it to finish.", 409)
            if self.batches.get(batch_id) is None:
                raise RequestError("That batch does not exist.", 404)
            run_id = self.store.create_run(kind, task, batch_id, "claude" if primary else "built-in planner",
                                           self.settings.model if primary else planner.label, context)
        if status["mode"] != "claude" and status["reason"]:
            self.store.note(run_id, status["reason"])
        if kind == "review":
            user_text = prompts.review_message(batch.name, len(batch.frame), scope, list_size, self.model.available, screen)
        else:
            user_text = prompts.question_message(question, batch.name, self.batches.summary(batch), selected, screen)
        ctx = tools.ToolContext(batches=self.batches, model=self.model, store=self.store, batch=batch, run_id=run_id,
                                scope_ids=scope, list_size=list_size, stock=self.stock)

        def work():
            try:
                if as_team:
                    final = team.run_review(run_id, user_text, ctx, self.settings, self.store, primary, list_size)
                else:
                    final = loop.run(run_id, user_text, ctx, self.settings, self.store, primary or planner, planner)
                self.store.finish_run(run_id, "completed", final)
            except Exception as err:  # the run must always end in a recorded state
                self.store.finish_run(run_id, "failed", None, error=f"{type(err).__name__}: {err}")

        if wait:
            work()
        else:
            thread = threading.Thread(target=work, name=run_id, daemon=True)
            self._threads[run_id] = thread
            thread.start()
        return run_id

    # ------------------------------------------------------------------ decisions
    def decide(self, proposal_id: str, decision: str, note: str | None = None, override: bool = False) -> dict:
        """`override` lets the planner change a decision they already took. See `Store.decide`."""
        if decision not in ("approved", "rejected"):
            raise RequestError("decision must be 'approved' or 'rejected'.")
        proposal = self.store.decide(proposal_id, decision, note=(note or "").strip()[:300] or None, override=bool(override))
        if proposal is None:
            raise RequestError("That proposal does not exist.", 404)
        if proposal.get("blocked_by"):
            raise RequestError("This aircraft has a newer proposal that is still open. Decide on that one instead; nothing changed.", 409)
        if proposal["status"] != decision:
            # The decision was not applied: someone decided first, or a newer review replaced this proposal.
            was = "replaced by a newer proposal" if proposal["status"] == "superseded" else f"already {proposal['status']}"
            raise RequestError(f"This proposal was {was}, so nothing changed. The list has been refreshed.", 409)
        return proposal

    def decide_many(self, batch_id: str, decision: str, ids: list | None = None, action: str | None = None, note: str | None = None) -> list:
        self.batch(batch_id)
        pending = [p for p in self.store.list_proposals(batch_id=batch_id, status="pending")
                   if (not ids or p["id"] in ids) and (not action or p["action"] == action)]
        done = []
        for p in pending:
            try:
                done.append(self.decide(p["id"], decision, note))
            except RequestError:        # decided by someone else in the meantime: leave it as it is
                continue
        return done

    # ------------------------------------------------------------------ spare parts (simulated)
    def decide_parts_request(self, request_id: str, decision: str, note: str | None = None, override: bool = False) -> dict:
        """Approve or reject the Supply agent's request. Approving sends nothing anywhere: the supply department is simulated.
        `override` lets the planner change a decision they already took."""
        if decision not in ("approved", "rejected"):
            raise RequestError("decision must be 'approved' or 'rejected'.")
        request = self.store.decide_parts_request(request_id, decision, (note or "").strip()[:300] or None, override=bool(override))
        if request is None:
            raise RequestError("That parts request does not exist.", 404)
        if request["status"] != decision:
            was = "replaced by a newer request" if request["status"] == "superseded" else f"already {request['status']}"
            raise RequestError(f"This parts request was {was}, so nothing changed.", 409)
        return request

    def set_stock(self, values: dict | None = None, preset: str | None = None, outage: bool | None = None) -> dict:
        if preset is not None and preset not in PRESETS:
            raise RequestError(f"preset must be one of {', '.join(PRESETS)}.")
        if values or preset:
            self.stock.set_levels(values, preset)
        if outage is not None:
            self.stock.simulated_outage = bool(outage)
        return self.stock.status()
